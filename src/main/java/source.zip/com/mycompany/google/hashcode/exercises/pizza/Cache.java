package com.mycompany.google.hashcode.exercises.pizza;

import java.util.List;

public class Cache {
    
    public int maxSize;

    public Cache(int maxSize) {
        this.maxSize = maxSize;
    }

    
}
