package com.mycompany.google.hashcode.exercises.pizza;

public class Video {
    
    public int size;

    public Video(int size) {
        this.size = size;
    }
}
