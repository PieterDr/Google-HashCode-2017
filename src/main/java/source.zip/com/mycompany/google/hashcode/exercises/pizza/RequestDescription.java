package com.mycompany.google.hashcode.exercises.pizza;

public class RequestDescription {
    
    public int vidId;
    public int requestAmount;

    public RequestDescription(int vidId, int requestAmount) {
        this.vidId = vidId;
        this.requestAmount = requestAmount;
    }
    
}
